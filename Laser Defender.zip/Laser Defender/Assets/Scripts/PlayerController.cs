﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {
	
	public float playerSpeed;
	public float padding = 0.5f;
	public float laserSpeed;
	public float fireRate;
	public float health = 250f;
	float xmin;
	float xmax;
	public GameObject laserPrefab;

	// Use this for initialization
	void Start () {
		float distance = transform.position.z - Camera.main.transform.position.z;
		Vector3 leftmost = Camera.main.ViewportToWorldPoint(new Vector3(0,0,distance));
		Vector3 rightmost = Camera.main.ViewportToWorldPoint(new Vector3(1,0,distance));
		xmin = leftmost.x+padding;
		xmax = rightmost.x-padding;
	}
	void Fire(){
	Vector3 offset = new Vector3(0f,0.5f,0f);
		GameObject laser = Instantiate(laserPrefab, this.transform.position + offset, Quaternion.identity) as GameObject;
		laser.rigidbody2D.velocity = new Vector3(0,laserSpeed,0);
	}
	// Update is called once per frame
	void Update () {
		if (Input.GetKey("left")) {
			this.transform.position += Vector3.left * playerSpeed * Time.deltaTime;
		} else if(Input.GetKey("right")) {
			this.transform.position += Vector3.right * playerSpeed * Time.deltaTime;
		}
		//Restrict Player to gamespace
		float newX = Mathf.Clamp(transform.position.x, xmin, xmax);
		this.transform.position = new Vector3(newX,transform.position.y,transform.position.z);
		if (Input.GetKeyDown ("space")) {
			InvokeRepeating("Fire", 0.000001f, fireRate);
		}
		if (Input.GetKeyUp ("space")) {
			CancelInvoke("Fire");
		}
		
	}
	
	void OnTriggerEnter2D(Collider2D collider){
		Projectile missile = collider.gameObject.GetComponent<Projectile>();
		
		if(missile){
			health -= missile.GetDamage();
			missile.Hit();
			if (health <= 0) {
				Destroy(gameObject);
			}
		}
	}
	
	
	/*void FixedUpdate () {
		float playerSpeed = 0.4f;
		float playerXPos = this.transform.position.x;
		Vector3 newPos;
		if (Input.GetKey("left")) {
			newPos = new Vector3(playerXPos - playerSpeed,this.transform.position.y,this.transform.position.z);
			this.transform.position = newPos;
		} else if (Input.GetKey("right")) {
			newPos = new Vector3(playerXPos + playerSpeed,this.transform.position.y,this.transform.position.z);
			this.transform.position = newPos;
		}
	}*/
}
